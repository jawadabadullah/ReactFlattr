import React, { useEffect, useState, useRef } from "react";
import { MapContainer, TileLayer, useMap } from "react-leaflet";
import MarkerClusterGroup from "react-leaflet-markercluster";
import Markers from "./FlatMarkers";
import { connect } from "react-redux";
import "leaflet/dist/leaflet.css";
import { getMapData } from "../../action/getMapData";
import "react-leaflet-markercluster/dist/styles.min.css";
import { Loader } from "../Loader/Loader";
import "leaflet/dist/leaflet.css";
import "leaflet-geosearch/dist/geosearch.css";
import { GeoSearchControl, OpenStreetMapProvider } from "leaflet-geosearch";
import { FlatIcon } from "./Icon";
import DepositMarkers from "./DepositMarkers";
import { ReactDOM } from "react";
import { RoomRent } from "./parameter/RoomRent";
import { Deposit } from "./parameter/Deposit";

function MapView({
  getMapData,
  loading,
  mapdata,
  parameter,
  current_parameter,
  current_facing,
}) {
  useEffect(() => {
    getMapData();
  }, []);

  function LeafletgeoSearch() {
    const map = useMap();
    useEffect(() => {
      const provider = new OpenStreetMapProvider();
      const searchControl = new GeoSearchControl({
        provider,
        style: "bar",
        autoComplete: true,
        marker: {
          FlatIcon,
        },
      });
      const legend = L.control({ position: "bottomleft" });

      legend.onAdd = () => {
        const div = L.DomUtil.create("div", "legend");
        div.innerHTML = "";
        return div;
      };

      legend.addTo(map);

      map.addControl(searchControl);
      return () => map.removeControl(searchControl);
    }, []);
    return null;
  }
  if (loading) {
    return <Loader />;
  }

  return (
    <MapContainer
      style={{ height: "500px" }}
      center={[12.9141, 74.856]}
      zoom={6}
      maxZoom={18}
    >
      <TileLayer
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        attribution='&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors'
      />

      {(() => {
        switch (current_parameter) {
          case "Rent":
            return (
              <MarkerClusterGroup>
                <Markers
                  venues={mapdata}
                  parameter={current_parameter}
                  facing={current_facing}
                />
              </MarkerClusterGroup>
            );

          case "deposit":
            return <DepositMarkers venues={mapdata} />;

          default:
            return (
              <MarkerClusterGroup>
                <Markers
                  venues={mapdata}
                  parameter={current_parameter}
                  facing={current_facing}
                />
              </MarkerClusterGroup>
            );
        }
      })()}
      <LeafletgeoSearch />
    </MapContainer>
  );
}

const mapStateToProps = (state) => ({
  mapdata: state.Map.mapData,
  loading: state.Map.loading,
  current_parameter: state.Map.current_parameter,
  current_facing: state.Map.current_facing,
});
export default connect(mapStateToProps, { getMapData })(MapView);
