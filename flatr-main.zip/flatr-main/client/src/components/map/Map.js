import React, { useState } from "react";
import "./style.css";
import "leaflet/dist/leaflet.css";
import MapView from "./MapView";
import { RoomRent } from "./parameter/RoomRent";
import { Deposit } from "./parameter/Deposit";
import Aside from "../landingcomponent/Home/Aside";
import { connect } from "react-redux";
import { Loader } from "../Loader/Loader";

const MapHexa = ({ current_parameter, loading }) => {
  const [state, setState] = useState({
    parameter: "Rent",
  });
  const parametersChange = (e) => {
    setState({
      ...state,
      parameter: e.target.value,
    });
  };

  console.log(current_parameter);

  return (
    <div>
      <div className="row ">
        <div className="col-12 col-lg-12 col-md-8">
          <MapView parameter={state.parameter} />
        </div>
      </div>
    </div>
  );
};
const mapStateToProps = (state) => ({
  loading: state.Map.loading,
  current_parameter: state.Map.current_parameter,
});
export default connect(mapStateToProps, null)(MapHexa);
